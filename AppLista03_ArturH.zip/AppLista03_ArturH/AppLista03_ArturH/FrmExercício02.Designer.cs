﻿namespace AppLista03_ArturH
{
    partial class FrmExercício02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblValorpag = new System.Windows.Forms.Label();
            this.txtValorPagar = new System.Windows.Forms.TextBox();
            this.lblValorgas = new System.Windows.Forms.Label();
            this.txtLitro = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblAbasteceu = new System.Windows.Forms.Label();
            this.pnlTitulo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Lucida Console", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(22, 52);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(234, 32);
            this.lblTitulo.TabIndex = 1;
            this.lblTitulo.Text = "Exercício02";
            this.lblTitulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(264, 12);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(273, 144);
            this.pnlTitulo.TabIndex = 2;
            // 
            // lblValorpag
            // 
            this.lblValorpag.AutoSize = true;
            this.lblValorpag.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorpag.ForeColor = System.Drawing.Color.Coral;
            this.lblValorpag.Location = new System.Drawing.Point(59, 204);
            this.lblValorpag.Name = "lblValorpag";
            this.lblValorpag.Size = new System.Drawing.Size(156, 22);
            this.lblValorpag.TabIndex = 3;
            this.lblValorpag.Text = "Valor a pagar ";
            this.lblValorpag.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtValorPagar
            // 
            this.txtValorPagar.Location = new System.Drawing.Point(308, 204);
            this.txtValorPagar.Name = "txtValorPagar";
            this.txtValorPagar.Size = new System.Drawing.Size(184, 20);
            this.txtValorPagar.TabIndex = 4;
            // 
            // lblValorgas
            // 
            this.lblValorgas.AutoSize = true;
            this.lblValorgas.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorgas.ForeColor = System.Drawing.Color.Coral;
            this.lblValorgas.Location = new System.Drawing.Point(29, 258);
            this.lblValorgas.Name = "lblValorgas";
            this.lblValorgas.Size = new System.Drawing.Size(222, 22);
            this.lblValorgas.TabIndex = 5;
            this.lblValorgas.Text = "Valor litro gasolina";
            // 
            // txtLitro
            // 
            this.txtLitro.Location = new System.Drawing.Point(308, 258);
            this.txtLitro.Name = "txtLitro";
            this.txtLitro.Size = new System.Drawing.Size(184, 20);
            this.txtLitro.TabIndex = 6;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(177)))), ((int)(((byte)(138)))));
            this.btnCalcular.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(328, 319);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(152, 52);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.BackColor = System.Drawing.Color.Transparent;
            this.lblResultado.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.Coral;
            this.lblResultado.Location = new System.Drawing.Point(430, 395);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(15, 22);
            this.lblResultado.TabIndex = 8;
            this.lblResultado.Text = "-";
            // 
            // lblAbasteceu
            // 
            this.lblAbasteceu.AutoSize = true;
            this.lblAbasteceu.BackColor = System.Drawing.Color.Transparent;
            this.lblAbasteceu.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAbasteceu.ForeColor = System.Drawing.Color.Coral;
            this.lblAbasteceu.Location = new System.Drawing.Point(253, 395);
            this.lblAbasteceu.Name = "lblAbasteceu";
            this.lblAbasteceu.Size = new System.Drawing.Size(171, 22);
            this.lblAbasteceu.TabIndex = 9;
            this.lblAbasteceu.Text = "VOCÊ ABASTECEU:";
            // 
            // FrmExercício02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(51)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAbasteceu);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtLitro);
            this.Controls.Add(this.lblValorgas);
            this.Controls.Add(this.txtValorPagar);
            this.Controls.Add(this.lblValorpag);
            this.Controls.Add(this.pnlTitulo);
            this.Name = "FrmExercício02";
            this.Text = "FrmExercício02";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblValorpag;
        private System.Windows.Forms.TextBox txtValorPagar;
        private System.Windows.Forms.Label lblValorgas;
        private System.Windows.Forms.TextBox txtLitro;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblAbasteceu;
    }
}