﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_ArturH
{
    public partial class FrmExercício02 : Form
    {
        public FrmExercício02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //capturar valores da tela
            float vlrPagar = float.Parse(txtValorPagar.Text);
            float vlrLitro = float.Parse(txtLitro.Text);
            float qtdLitros;

            //calculo
            qtdLitros = vlrPagar / vlrLitro;

            //Mostrar resultado
            lblResultado.Text = qtdLitros + "LITRO(S)";
        }

    }
}
